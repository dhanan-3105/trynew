package com.example.demorestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemorestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
